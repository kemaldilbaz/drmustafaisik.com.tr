# Dr. Mustafa Işık - Medikal Estetik Web Sitesi

Bu depo, Dr. Mustafa Işık Medikal Estetik kliniğinin tek sayfalık (single-page) web sitesini içerir.

## İçerik

- `index.html` — Sitenin tamamı (HTML + CSS + JS), görseller base64 olarak dosya içine gömülüdür. Ayrı bir görsel/asset klasörüne ihtiyaç yoktur.

## Yayınlama (GitHub Pages ile ücretsiz barındırma)

1. Bu depoyu GitHub'a push edin.
2. Depo ayarlarından **Settings > Pages** kısmına gidin.
3. **Source** olarak `main` branch ve `/ (root)` klasörünü seçin, kaydedin.
4. Birkaç dakika içinde siteniz `https://kullaniciadi.github.io/depo-adi/` adresinden yayında olacaktır.

## Yerelde önizleme

`index.html` dosyasına çift tıklamanız yeterli, tarayıcınızda doğrudan açılır. Sunucuya ihtiyaç yoktur.
